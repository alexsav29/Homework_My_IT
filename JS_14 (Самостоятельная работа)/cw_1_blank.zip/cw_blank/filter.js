const filter = function() {

};

filter('portfolio'); // id