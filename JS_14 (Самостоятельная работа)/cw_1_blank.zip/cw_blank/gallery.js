const gallery = function() {
    
};

gallery('gallery'); // id